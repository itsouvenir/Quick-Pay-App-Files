package com.example.stock.stock;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class Configurations extends AppCompatActivity {
    Button save;
    TextView output;
    String path;
    File uri,endpoint;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configurations);

        if(!Environment.getRootDirectory().isDirectory()){
            Log.d("MyApp","Error");
        } else{
            File directory =new File(Environment.getExternalStorageDirectory()+File.separator +"Config");
            directory.mkdirs();
            uri= new File(directory,"uri.txt");
            endpoint= new File(directory,"endpoint.txt");
           // path=Environment.getExternalStorageState()+endpoint;

        }

        //Onclick listener to write into file
        save= findViewById(R.id.save);
        output=findViewById(R.id.output);

        save.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                TextView text= findViewById(R.id.endpoint);

                try {
                    endpoint.createNewFile();
                    FileOutputStream Fout= new FileOutputStream(endpoint);
                    OutputStreamWriter myOutWriter=new OutputStreamWriter(Fout);
                    String data=text.getText().toString();
                    myOutWriter.append(data);
                }catch (IOException e){

                    Log.e("Exception","File write Failed" +e.toString());
                }
            }
        });
    }
}

package com.example.stock.stock;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class HomeActivity extends AppCompatActivity {
    Button view_stock;
    Button place_order;
    Button payment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
     /*   //Initial Config Intent on First Run
     Boolean isFirstRun= getSharedPreferences("PREFERENCE",MODE_PRIVATE).getBoolean("isFirstRun",true);
     if(isFirstRun){
         startActivity(new Intent(HomeActivity.this,Configurations.class));
         Toast.makeText(HomeActivity.this,"First Run",Toast.LENGTH_LONG).show();
     }
     getSharedPreferences("PREFERENCE",MODE_PRIVATE).edit().putBoolean("isFirstRun",false).commit();

     //First Run Intent ends*/
        //Read From File
        File output = Environment.getExternalStorageDirectory();
        File endpoint= new File(output,"Config"+File.separator+"endpoint.txt");
        StringBuilder text= new StringBuilder();
        try {
            BufferedReader br =new BufferedReader(new FileReader(endpoint));
            String line;
            while ((line=br.readLine()) !=null){
                text.append(line);
                text.append('\n');
            }
            br.close();
        }catch (IOException e){
            Log.e("Error","Cant read file"+e.toString());
        }
        TextView tv = findViewById(R.id.output);
        tv.setText(text.toString());
        //Read End

    //Onclick listener for  view stock activity
        view_stock= findViewById(R.id.view);
        view_stock.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent viewstock = new Intent(getApplicationContext(),ViewStockActivity.class);
                startActivity(viewstock);
                HomeActivity.this.finish();
            }
        });
        //Stock Activity ends here
    //Onclick listener for Place an order
        place_order= findViewById(R.id.place);
        place_order.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent PlaceOrder = new Intent(getApplicationContext(),Place_OrderActivity.class);
                startActivity(PlaceOrder);
                HomeActivity.this.finish();
            }
        });
        //Place an order ends here
    // Onclick listener for Pay for goods
        payment= findViewById(R.id.pay);
        payment.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent payment = new Intent(getApplicationContext(),Pay4GoodsActivity.class);
                startActivity(payment);
                HomeActivity.this.finish();
            }
        });
        //Pay for goods ends here

    }
}

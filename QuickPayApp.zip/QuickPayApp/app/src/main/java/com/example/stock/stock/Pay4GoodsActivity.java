package com.example.stock.stock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.stock.stock.adapters.StockAdapter;
import com.example.stock.stock.clients.Sender;
import com.example.stock.stock.clients.StockRestClient;
import com.example.stock.stock.models.Stock;
import com.loopj.android.http.JsonHttpResponseHandler;


import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.message.BasicHeader;

public class Pay4GoodsActivity extends AppCompatActivity {
    private ListView noteList;
    Button Pay;
    TextView status;

    String urlAddress="http://stock.semuandassociates.com/index.php/api/payment/add";
    //String urlAddress="http://192.168.137.44/stock/content/index.php/api/payment/add";
    EditText amount, pid, qty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay4_goods);

        getPayment();

        //INITIALIZE UI FIELDS
        amount = (EditText) findViewById(R.id.price);
        pid = (EditText) findViewById(R.id.pid);
        qty = (EditText) findViewById(R.id.qty);


        //Onclick listener for  view stock activity
        Pay= findViewById(R.id.pay);
        Pay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                //START ASYNC TASK
                Sender s=new Sender(Pay4GoodsActivity.this,urlAddress, amount, pid, qty );
                s.execute();
            }
        });
        //Stock Activity ends here


    }

    private void getPayment() {
        List<BasicHeader> headers = new ArrayList<>();
        headers.add(new BasicHeader("Accept", "application/json"));

        StockRestClient.get(Pay4GoodsActivity.this, "/api/products", headers.toArray(new cz.msebera.android.httpclient.Header[headers.size()]),
                null, new JsonHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, JSONArray response) {
                        ArrayList<Stock> stockArray = new ArrayList<Stock>();
                        StockAdapter stockAdapter = new StockAdapter(Pay4GoodsActivity.this, stockArray);

                        for (int i = 0; i < response.length(); i++) {
                            try {
                                stockAdapter.add(new Stock(response.getJSONObject(i)));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        noteList = (ListView) findViewById(R.id.list_notes);
                        noteList.setAdapter(stockAdapter);
                    }
                });
    }
}

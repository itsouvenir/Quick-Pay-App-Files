package com.example.stock.stock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.stock.stock.clients.Orders;
import com.example.stock.stock.clients.Sender;

public class Place_OrderActivity extends AppCompatActivity {

    Button Pay;
    //TextView status;

    String urlAddress="http://stock.semuandassociates.com/index.php/api/order/add";
    //String urlAddress="http://192.168.137.44/stock/content/index.php/api/order/add";
    EditText item, qty, loc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place__order);


        //INITIALIZE UI FIELDS
        loc = (EditText) findViewById(R.id.amount);
        item = (EditText) findViewById(R.id.pid);
        qty = (EditText) findViewById(R.id.qty);


        //Onclick listener for  view stock activity
        Pay= findViewById(R.id.pay);
        Pay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                //START ASYNC TASK
                Orders s=new Orders(Place_OrderActivity.this,urlAddress, item, loc, qty );
                s.execute();
            }
        });

    }
}

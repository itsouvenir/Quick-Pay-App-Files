package com.example.stock.stock;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.example.stock.stock.adapters.StockAdapter;
import com.example.stock.stock.clients.StockRestClient;
import com.example.stock.stock.models.Stock;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;

public class ViewStockActivity extends AppCompatActivity {

    private ListView noteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_stock);

        getNotes();
    }

    private void getNotes() {
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader("Accept", "application/json"));

        StockRestClient.get(ViewStockActivity.this, "/api/products", headers.toArray(new Header[headers.size()]),
                null, new JsonHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                        ArrayList<Stock> stockArray = new ArrayList<Stock>();
                        StockAdapter stockAdapter = new StockAdapter(ViewStockActivity.this, stockArray);

                        for (int i = 0; i < response.length(); i++) {
                            try {
                                stockAdapter.add(new Stock(response.getJSONObject(i)));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        noteList = (ListView) findViewById(R.id.list_notes);
                        noteList.setAdapter(stockAdapter);
                    }
                });
    }


}
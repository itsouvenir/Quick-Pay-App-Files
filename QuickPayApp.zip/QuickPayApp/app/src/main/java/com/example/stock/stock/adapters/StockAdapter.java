package com.example.stock.stock.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.stock.stock.R;
import com.example.stock.stock.models.Stock;

import java.util.ArrayList;

public class StockAdapter extends ArrayAdapter<Stock> {
    private static class ViewHolder {
        TextView productName;
        TextView quantity;
        TextView price;
        TextView meausre;
    }

    public StockAdapter(Context context, ArrayList<Stock> stocks) {
        super(context, R.layout.item_products, stocks);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Stock stock = getItem(position);
        ViewHolder viewHolder;

        if (convertView == null) {
            viewHolder = new ViewHolder();

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_products, parent, false);

            viewHolder.productName = (TextView) convertView.findViewById(R.id.value_note_id);
            viewHolder.quantity = (TextView) convertView.findViewById(R.id.value_note_title);
            viewHolder.price = (TextView) convertView.findViewById(R.id.value_note_price);
            viewHolder.meausre = (TextView) convertView.findViewById(R.id.value_note_umeasure);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.productName.setText(stock.getProductName());
        viewHolder.quantity.setText(stock.getQuantity());
        viewHolder.price.setText(stock.getPrice());
        viewHolder.meausre.setText(stock.getMeasure());

        return convertView;
    }
}
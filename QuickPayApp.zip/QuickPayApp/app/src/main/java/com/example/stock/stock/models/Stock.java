package com.example.stock.stock.models;

import org.json.JSONException;
import org.json.JSONObject;

public class Stock {

    private String productName;
    private String Quantity;
    private String Price;
    private String measure;

    public Stock(JSONObject object) {
        try {
            this.productName = object.getString("pname");
            this.Quantity = object.getString("qty");
            this.Price = object.getString("uprice");
            this.measure= object.getString("umeasure");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public Stock(String Quantity, String Price) {
        this.Quantity = Quantity;
        this.Price = Price;
    }

    public String getProductName() {
        return this.productName;
    }
    public String getQuantity() {
        return this.Quantity;
    }

    public void setQuantity(String quantity) {
        this.Quantity = quantity;
    }

    public String getPrice() {
        return this.Price;
    }

    public void setPrice(String price) {
        this.Price = price;
    }
    public String getMeasure() {
        return this.measure;
    }

    public void setMeasure(String measure) {
        this.measure = measure;
    }
}

package com.example.stock.stock;

import static org.junit.Assert.*;

public class Pay4GoodsActivityTest {

}